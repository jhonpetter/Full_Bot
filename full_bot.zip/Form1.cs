using System;
using System.Diagnostics;
using System.Linq;
using System.Windows.Forms;

namespace Full_Bot
{
    public partial class Form1 : Form
    {
        private const int UiTickIntervalMs = 200;
        private const int MaxRenderedEntities = 80;

        private readonly TreeConfigRoot _config;
        private MemoryProcess _mem;
        private AsmRunner _asm;

        private PlayerCore _player;
        private PlayerBuffs _buffs;
        private PlayerInventory _inventory;
        private PlayerParty _party;
        private PlayerPets _pets;
        private PlayerSkills _skills;
        private PlayerFriends _friends;
        private TasksQuestActive _questActive;
        private TasksQuestNews _questNews;
        private TasksLoader _tasksLoader;
        private WorldEntities _world;

        private BotController _botController;
        private Timer _uiTimer;

        private MapPanel _mapPanel;
        private PlayerStatsPanel _statsPanel;

        public Form1()
        {
            InitializeComponent();
            _config = ConfigManager.Load(@"Config\config.json");
            SetupCustomUi();
            AttachToProcess();
            StartUiLoop();
        }

        private void tmrUpdate_Tick(object sender, EventArgs e)
        {
            OnUiTick(sender, e);
        }
        private void SetupCustomUi()
        {
            _statsPanel = new PlayerStatsPanel
            {
                Dock = DockStyle.Left,
                Width = 310
            };

            _mapPanel = new MapPanel
            {
                Dock = DockStyle.Fill
            };

            Controls.Add(_mapPanel);
            Controls.Add(_statsPanel);
        }

        private void AttachToProcess()
        {
            string procName = _config.DetectProcessName("elementclient");
            var proc = Process.GetProcessesByName(procName).FirstOrDefault();
            if (proc == null)
            {
                _statsPanel.SetStatus($"Processo '{procName}' não encontrado.");
                return;
            }

            _mem = new MemoryProcess(proc, _config);
            _asm = new AsmRunner();

            _player = new PlayerCore(_mem, _asm);
            _buffs = new PlayerBuffs(_mem, _player);
            _inventory = new PlayerInventory(_mem, _player);
            _party = new PlayerParty(_mem, _asm, _player);
            _pets = new PlayerPets(_mem, _player);
            _skills = new PlayerSkills(_mem, _player);
            _friends = new PlayerFriends(_mem, _player);
            _questActive = new TasksQuestActive(_mem, _player, _inventory);
            _questNews = new TasksQuestNews(_mem);
            _tasksLoader = new TasksLoader();
            _world = new WorldEntities(_mem);

            var combat = new BotCombat(_player, _skills, _world);
            var questRunner = new BotQuestRunner(_player, _questActive, _inventory, _world, _tasksLoader, combat);
            var partyFollow = new BotPartyFollow(_player, _party, _world);

            _botController = new BotController(_player, _world, _tasksLoader, combat, questRunner, partyFollow);

            _mapPanel.Bind(_player, _world);
            _statsPanel.SetStatus($"Conectado a {proc.ProcessName} (PID {proc.Id})");
        }

        private void StartUiLoop()
        {
            _uiTimer = new Timer { Interval = UiTickIntervalMs };
            _uiTimer.Tick += OnUiTick;
            _uiTimer.Start();
        }

        private void OnUiTick(object sender, EventArgs e)
        {
            if (_mem == null || _player == null) return;

            try
            {
                _botController?.Tick();

                var buffs = _buffs?.GetActiveBuffs();
                var bag = _inventory?.GetBagItems();
                var party = _party?.GetMembers();
                var quests = _questActive?.GetActiveQuestTree();
                var entities = _world?.GetMobsAndNpcs()?.Take(MaxRenderedEntities).ToList();

                _statsPanel.UpdateData(
                    _player,
                    buffs?.Count ?? 0,
                    bag?.Count ?? 0,
                    party?.Count ?? 0,
                    quests?.Count ?? 0,
                    entities?.Count ?? 0);

                _mapPanel.Invalidate();
            }
            catch (Exception ex)
            {
                _statsPanel.SetStatus($"Erro no tick: {ex.Message}");
            }
        }

        protected override void OnFormClosed(FormClosedEventArgs e)
        {
            _uiTimer?.Stop();
            _uiTimer?.Dispose();
            _asm?.Dispose();
            _mem?.Dispose();
            base.OnFormClosed(e);
        }
    }
}