﻿using System.Collections.Generic;
using System.Linq;

namespace Full_Bot
{
    public static class BotHub
    {
        private static readonly object _sync = new object();
        public static List<BotController> ActiveBots { get; } = new List<BotController>();

        public static void Register(BotController bot)
        {
            lock (_sync)
            {
                if (!ActiveBots.Contains(bot))
                    ActiveBots.Add(bot);
            }
        }

        public static void Unregister(BotController bot)
        {
            lock (_sync)
            {
                ActiveBots.Remove(bot);
            }
        }

        public static List<BotController> GetSnapshot()
        {
            lock (_sync)
            {
                return ActiveBots.ToList();
            }
        }

        public static BotController FindBotByPlayerId(uint playerId)
        {
            lock (_sync)
            {
                return ActiveBots.FirstOrDefault(b => b.Player.Id == playerId);
            }
        }
    }
}
