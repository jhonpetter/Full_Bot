﻿use32
org {ALLOC_ADDR}

push ebp
mov ebp, esp
push edi
push ebx
push esi

; 1. Resolve o ponteiro do personagem (HostPlayer)
mov eax, [{BASE_ADDR}]
test eax, eax
je ExitSkill
mov ecx, [eax+{OFF_GAMERUNOFFSET}]
test ecx, ecx
je ExitSkill
mov ebx, [ecx+{OFF_HOSTPLAYEROFFSET}]
test ebx, ebx
je ExitSkill

; 2. Aloca buffer de 12 bytes (0x0C)
mov ecx, {PACKET_MGR}
push 0x0C
call {FUNC_ALLOCPACKET}
mov esi, eax
test esi, esi
je ExitSkill

; 3. Monta o pacote 0x0029 (Opcode + SkillID + Flags + TargetID atual)
mov word [esi], 0x0029
mov dword [esi+0x02], {SKILL_ID}
mov byte [esi+0x06], 0x01
mov byte [esi+0x07], 0x01
mov edi, [ebx+{OFF_PLAYER_TARGETID}]
mov [esi+0x08], edi

; 4. Valida o gerenciador de rede e envia
mov eax, [{BASE_ADDR}]
test eax, eax
je FreeBuffer
mov ecx, [eax+{OFF_NETWORKOFFSET}]
test ecx, ecx
je FreeBuffer

push esi
push 0x000000B5
push 0x000000A9
call {FUNC_SENDPACKET}

FreeBuffer:
mov ecx, esi
call {FUNC_FREEPACKET}

ExitSkill:
pop esi
pop ebx
pop edi
mov esp, ebp
pop ebp
ret 4
