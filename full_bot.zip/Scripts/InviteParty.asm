﻿use32
org {ALLOC_ADDR}

push ebp
mov ebp, esp
push esi

mov eax, [{BASE_ADDR}]
test eax, eax
je ExitInvite
mov ecx, [eax+{OFF_NETWORKOFFSET}]
test ecx, ecx
je ExitInvite

push {TARGET_PLAYER_ID}
call {FUNC_INVITEPARTY}

ExitInvite:
pop esi
mov esp, ebp
pop ebp
ret 4
