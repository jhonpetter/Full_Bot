﻿use32
org {ALLOC_ADDR}

push ebp
mov ebp, esp
push edi
push ebx
push esi

; 1. Resolve a base oficial do Player (HostPlayer)
mov eax, [{BASE_ADDR}]
test eax, eax
je ExitFlyAlt
mov edx, [eax+{OFF_GAMERUNOFFSET}]
test edx, edx
je ExitFlyAlt
mov ebx, [edx+{OFF_HOSTPLAYEROFFSET}]
test ebx, ebx
je ExitFlyAlt

; 2. Aloca o bloco de 128 bytes (0x80) no Heap da engine
mov ecx, {HEAP_MGR}
push 0x80
call {FUNC_ALLOCBLOCK}
mov esi, eax
test esi, esi
je ExitFlyAlt

; 3. Preenche o comando de alteração de altitude (type 1 = toggle/fly alt)
mov dword [esi], 0x0000014A
mov dword [esi+0x0C], 0x00000001
mov dword [esi+0x10], {FLY_ALT}

mov eax, 0x0000006D
mov ecx, ebx
mov edi, ebx

push esi
call {FUNC_MOVETO}

ExitFlyAlt:
pop esi
pop ebx
pop edi
mov esp, ebp
pop ebp
ret 4
