use32
org {ALLOC_ADDR}

push ebp
mov ebp, esp
push ebx
push esi

; 1. Aloca buffer de 10 bytes (0x0A)
mov ecx, {PACKET_MGR}
push 0x0A
call {FUNC_ALLOCPACKET}
mov esi, eax
test esi, esi
je ExitParty

; 2. Monta o pacote 0x001C (Opcode + LeaderID + TimeHit)
mov word [esi], 0x001C
mov dword [esi+0x02], {LEADER_ID}
mov dword [esi+0x06], {TIME_HIT}

; 3. Valida o gerenciador de rede e envia
mov eax, [{BASE_ADDR}]
test eax, eax
je FreeBuffer
mov ecx, [eax+{OFF_NETWORKOFFSET}]
test ecx, ecx
je FreeBuffer

push esi
push 0x000000B3
push 0x000000A9
call {FUNC_SENDPACKET}

FreeBuffer:
mov ecx, esi
call {FUNC_FREEPACKET}

ExitParty:
pop esi
pop ebx
mov esp, ebp
pop ebp
ret 4
