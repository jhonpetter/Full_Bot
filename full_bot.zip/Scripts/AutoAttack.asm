﻿use32
org {ALLOC_ADDR}

pushad

mov eax, [{BASE_ADDR}]
test eax, eax
je ExitAttack
mov ecx, [eax+{OFF_GAMERUNOFFSET}]
test ecx, ecx
je ExitAttack
mov ecx, [ecx+{OFF_HOSTPLAYEROFFSET}]
test ecx, ecx
je ExitAttack

call {FUNC_AUTOATTACK}

ExitAttack:
popad
ret 4
