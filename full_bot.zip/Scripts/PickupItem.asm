﻿use32
org {ALLOC_ADDR}

pushad

mov eax, [{BASE_ADDR}]
test eax, eax
je ExitPickup
mov ecx, [eax+{OFF_GAMERUNOFFSET}]
test ecx, ecx
je ExitPickup
mov ecx, [ecx+{OFF_HOSTPLAYEROFFSET}]
test ecx, ecx
je ExitPickup

push {IS_MAT}
push {ITEM_SERVER_ID}
call {FUNC_PICKUPITEM}

ExitPickup:
popad
ret 4
