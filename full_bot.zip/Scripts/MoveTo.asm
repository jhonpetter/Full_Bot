﻿use32
org {ALLOC_ADDR}

push ebp
mov ebp, esp
push edi
push ebx
push esi

mov eax, [{BASE_ADDR}]
test eax, eax
je ExitMove
mov edx, [eax+{OFF_GAMERUNOFFSET}]
test edx, edx
je ExitMove
mov edi, [edx+{OFF_HOSTPLAYEROFFSET}]
test edi, edi
je ExitMove

mov ecx, {HEAP_MGR}
push 0x80
call {FUNC_ALLOCBLOCK}
mov esi, eax
test esi, esi
je ExitMove

mov dword [esi+0x0C], 0x00000000
mov dword [esi+0x10], {INT_X}
mov dword [esi+0x14], {INT_Z}
mov dword [esi+0x18], {FLY_MODE}

mov ecx, edi
push esi
call {FUNC_MOVETO}

ExitMove:
pop esi
pop ebx
pop edi
mov esp, ebp
pop ebp
ret 4
