﻿use32
org {ALLOC_ADDR}

pushad
mov esi, {TARGET_ID}
push esi

mov eax, [{BASE_ADDR}]
test eax, eax
je ExitTarget
mov ecx, [eax+{OFF_GAMERUNOFFSET}]
test ecx, ecx
je ExitTarget
mov ecx, [ecx+{OFF_HOSTPLAYEROFFSET}]
test ecx, ecx
je ExitTarget

mov [ecx+{OFF_PLAYER_CONFIRMTARGETID}], esi
call {FUNC_SELECTTARGET}

ExitTarget:
popad
ret 4
